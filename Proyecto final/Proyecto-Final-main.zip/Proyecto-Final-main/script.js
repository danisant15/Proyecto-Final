window.alert("¡Bienvenido/a al blog Queen Forever!")
var edad = prompt("¿Cuantos años tienes?");
if (edad >=18) {
        alert("Eres mayor de edad, puedes entrar.");
    } else {
        alert("Eres menor de edad, no puedes entrar.");
    }

function sorteo(){
    let dni = "Ingresa tu dni"
    let mensaje = "¡Gracias, ya estás participando del sorteo!"
    console.log(mensaje);
    alert(mensaje)
}

